
## Play now

Feel free to play:

* https://bekeshbekesh.herokuapp.com/
  > Might not respond right-away, just wait some seconds



## Contributing

There are many ways you can contribute:

* Update / Add documentation in the wiki of the GitHub repository
* Extend this README
* Create feature requests and bug reports
* Solve issues by creating Pull Requests
* Tell your friends about the project
* Curating the persian word lists

## Credits

* Translated and Edited by: Ahmadrezadl
* Main Project: [Scribble-rs](https://github.com/scribble-rs/scribble.rs)
